<?php
/****************************************************/
/************** Created by : Vivek Gupta ************/
/***************     www.vsgupta.in     *************/
/***************     www.iotmonk.com     *************/
/****************************************************/ 
 
define('DB_USER', "root");     // Your database user name
define('DB_PASSWORD', "sox10foxd3");			// Your database password (mention your db password here)
define('DB_DATABASE', "catan"); // Your database name
define('DB_SERVER', "localhost");			// db server (Mostly will be 'local' host)
 
?>